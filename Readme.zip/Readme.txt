Thanks for downloading this template!

Template Name: Landify
Template URL: https://bootstrapmade.com/landify-bootstrap-landing-page-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
